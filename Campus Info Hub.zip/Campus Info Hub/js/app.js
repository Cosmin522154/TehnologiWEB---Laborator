        let campusData = [];

        // Funcția care aduce datele din JSON
        async function fetchData() {
            try {
                const response = await fetch('data/resources.json');
                const data = await response.json();
                campusData = data.resources;
                renderResources(campusData);
            } catch (error) {
                document.getElementById('content-list').innerHTML = "Eroare la încărcarea datelor.";
                console.error(error);
            }
        }

        // Funcția care afișează resursele pe ecran
        function renderResources(items) {
            const listDiv = document.getElementById('content-list');
            listDiv.innerHTML = ""; // Curățăm lista

            items.forEach(item => {
                const div = document.createElement('div');
                div.className = "resource-item";
                div.innerHTML = `
                    <h3>${item.name}</h3>
                    <p><strong>Locație:</strong> ${item.location}</p>
                    <p><strong>Program:</strong> ${item.program}</p>
                    <p><em>Tags: ${item.tags.join(', ')}</em></p>
                    <a href="${item.url}">Deschide Pagina</a>
                `;
                listDiv.appendChild(div);
            });
        }

        // Funcția de filtrare
        function filterByType(type) {
            if (type === 'all') {
                renderResources(campusData);
            } else {
                const filtered = campusData.filter(item => item.type === type);
                renderResources(filtered);
            }
        }

        // Pornim încărcarea la deschiderea paginii
        window.onload = fetchData;